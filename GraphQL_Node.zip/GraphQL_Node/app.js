'use strict'
const express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    path = require('path'),
    index = require('./routes/index'),
    users = require('./routes/users'),
    port = process.env.PORT || 6117,
    http = require('http').createServer(app),
    socket = require('socket.io').listen(http)

var connections = []

socket.sockets.on('connection', function (client) {
    connections.push(client.id)
    
    client.on('get message', function (data) {
        client.broadcast.emit('send an message', data)
    })
    client.on('disconnect', function () {
        connections.splice(connections.indexOf(client.id))
    })
})

http.listen(port, function () {
    console.log('Running on port: '+port)
})

app.use(require('morgan')('dev'))
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())
app.use(express.static(__dirname))

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))

app.use('/', index)
app.use('/users', users)